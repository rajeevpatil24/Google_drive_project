import requests
import json
from InputVariables import  Get_File_list_API


def get_file_name_and_id(filename,YOUR_ACCESS_TOKEN,YOUR_API_KEY):
    data = requests.get(Get_File_list_API + YOUR_API_KEY, headers={'Content-Type': 'application/json',
                                                                   'Authorization': 'Bearer {}'.format(
                                                                       YOUR_ACCESS_TOKEN)},stream=True)

    response_json = json.loads(data.text)
    print (data.text)
    if data.status_code == 401:
        print ("YOUR_ACCESS_TOKEN is expired or wrong")

    else:
        for file_name in response_json['files']:
            if file_name['name'] == filename:
                return file_name['name'], file_name['id']
        else:
            print ("File name : {}  not  Found in Google Drive ".format(filename))
            return None, None

