from Download_file_from_gdrive import download_file as df
from Utilities.get_file_name_and_id import get_file_name_and_id as gdata
from InputVariables import YOUR_ACCESS_TOKEN, YOUR_API_KEY, Download_file_API  # input_File_name
import requests
import os
import filecmp
import shutil
import sys

argumentList = sys.argv
if len(argumentList) <= 2:
    print ("Invalid arguments given  ")
    print ("To run it properly use : python File_downloader.py file_name")
else:
    input_File_name = sys.argv[1:]
    for single_file_name in input_File_name:
        print (single_file_name)
        Filename, FileId = gdata(single_file_name, YOUR_ACCESS_TOKEN, YOUR_API_KEY)
        if (Filename and FileId) != None:
            if single_file_name == Filename:
                print ("File is getting downloaded with File name : ---  {} and File ID : ----  {}".format(Filename,
                                                                                                           FileId))
                df(single_file_name, FileId)
        else:
            print ("Failed to download the file from Google drive since file not present")
