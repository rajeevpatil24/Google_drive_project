from Utilities.get_file_name_and_id import get_file_name_and_id as gdata
from InputVariables import YOUR_ACCESS_TOKEN, YOUR_API_KEY, Download_file_API, input_File_name
import requests
import os
import filecmp
import shutil
import sys

def download_file(file_name, fileId):
    data = requests.get(Download_file_API + fileId,
                        headers={'Content-Type': 'application/json',
                                 'Authorization': 'Bearer {}'.format(YOUR_ACCESS_TOKEN)}, allow_redirects=True,
                        stream=True)
    #print (data.text)
    open(file_name, 'wb').write(data.content)
    downloaded_file_path = os.getcwd()
    file_details = os.stat(file_name)
    if file_details.st_size > 0:
        print ("File Size Downloaded  : --- {}".format(file_details.st_size))
    else:
        print ("You have downloaded Empty File")
    dir_path = os.getcwd() + str('/Test_Suites/Updated/')
    os.chdir(dir_path)
    new_file_name = dir_path + str(file_name)
    old_file_name = downloaded_file_path + '/Test_Suites/' + str(file_name)
    #print ("new_file_name", new_file_name)
    #print ("old_file_name", old_file_name)
    if os.path.isfile(file_name) :
        print ("File already exists , so checking for the changes / updation details")
        result = filecmp.cmp(new_file_name, old_file_name, shallow=False)
        if not result:
            print ("Replacing updated file in Updated directory")
            shutil.copyfile(old_file_name, new_file_name)
        else:
            print ("No changes found in file , so not replacing it with any data in Updated folder")
    else:
        print ("File doesn't exists , copying it to Updated folder")
        shutil.copyfile(old_file_name, new_file_name)



