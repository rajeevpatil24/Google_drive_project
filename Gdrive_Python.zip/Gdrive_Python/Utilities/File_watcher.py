############################################################################################################################################
#######Script responsible for watching the file whether it has copied to your local system or not ######
###### It will wait for one hour in 1 minte time it will check and once it finds file it returns True ######


import os
import time

def watch_file( filename, time_limit=3600, check_interval=60 ):
    '''Return true if filename exists, if not keep checking once every check_interval seconds for time_limit seconds.
    time_limit defaults to 1 hour
    check_interval defaults to 1 minute
    '''

    now = time.time()
    last_time = now + time_limit

    while time.time() <= last_time:
        if os.path.exists( filename ):
             return True
        else:
            # Wait for check interval seconds, then check again.
            time.sleep( check_interval )

    return False