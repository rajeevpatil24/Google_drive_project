############################################################################################################################################
###########File which has all test case for downloading a file which includes checking the size of the file######
###########  checking whether file already exists , if already present then comparing it with newly downloaded file##########
########### else copying it under Updated directory#######
from Utilities.get_file_name_and_id import get_file_name_and_id as gdata
from InputVariables import YOUR_ACCESS_TOKEN, YOUR_API_KEY, Download_file_API
from Utilities.File_watcher import watch_file
import requests
import os
import filecmp
import shutil
import sys
import time


def download_file(file_name, fileId):
    data = requests.get(Download_file_API + fileId,
                        headers={'Content-Type': 'application/json',
                                 'Authorization': 'Bearer {}'.format(YOUR_ACCESS_TOKEN)}, allow_redirects=True,
                        stream=True)
    # print (data.text)
    open(file_name, 'wb').write(data.content)
    downloaded_file_path = os.getcwd()
    #checking for the downloaded file size here and we are just passing a alert to customer that he has downloaded zero byte file incase
    print ("downloaded_file_path", downloaded_file_path)
    file_details = os.stat(file_name)
    if file_details.st_size > 0:
        print ("File Size Downloaded  : --- {}".format(file_details.st_size))
    else:
        print ("You have downloaded Empty File")
    dir_path = os.getcwd() + str('/Test_Suites/Updated/')
    print ("dir path", dir_path)
    # os.chdir(dir_path)
    old_file_name = downloaded_file_path + '/' + str(file_name)
    new_file_name = downloaded_file_path + '/Test_Suites/Updated/' + str(file_name)
    #print ("new_file_name", new_file_name)
    #print ("old_file_name", old_file_name)
    #print (os.path.exists(downloaded_file_path))
    file_status=watch_file(old_file_name)
    #print  (file_status)
    if file_status:
        print ("File Successfully dowloaded {}".format(old_file_name))
    #################From here we are checking for the file which is already present in the system with newly downloaded one
    if os.path.isfile(new_file_name):
        print ("File Present Comparing new one with old one")
        result = filecmp.cmp(new_file_name, old_file_name, shallow=False)
        if not result:
            print("Replacing updated file in Updated directory")
        else:
            print ("No changes found in file , so not replacing it with any data in Updated folder")
    else:
        # if file is not present then we are copying it and not comparing since its first time download in the directory
        print ("Copying file under Updated directory ")
        shutil.copyfile(old_file_name, new_file_name)
